import pandas as pd
import sqlalchemy as sal
import logging
from utils import show_message_box

def connect_to_database(app):
    connection_url = (
        f"{app.dialect_edit.text()}+{app.driver_edit.text()}://"
        f"{app.username_edit.text()}:{app.password_edit.text()}@"
        f"{app.host_edit.text()}:{app.port_edit.text()}/"
        f"{app.database_edit.text()}"
    )

    try:
        engine = sal.create_engine(connection_url)
        app.conn = engine.connect()
        app.status_label.setText('Status: Connected to Database')

        app.table_name = app.table_edit.text().strip()
        if app.table_name:
            try:
                pd.read_sql_table(app.table_name, app.conn)
                app.status_label.setText(f'Status: Connected to Table "{app.table_name}"')
                show_message_box('Connection Successful', f'Connected to the table "{app.table_name}" successfully.', QMessageBox.Information)
            except Exception as e:
                app.table_name = None
                show_message_box('Table Connection Error', f'Table "{app.table_name}" does not exist. Error: {e}', QMessageBox.Critical)
        else:
            show_message_box('Connection Successful', 'Connected to the database successfully. You can create a new table by importing an Excel file.', QMessageBox.Information)

        app.stacked_widget.setCurrentIndex(1)
    except Exception as e:
        app.conn = None
        app.status_label.setText('Status: Connection Failed')
        logging.error(f'Error connecting to database: {e}')
        show_message_box('Connection Error', f'Error connecting to database: {e}', QMessageBox.Critical)

def disconnect_from_database(app):
    if app.conn:
        try:
            app.conn.close()
            app.conn = None
            app.table_name = None
            app.status_label.setText('Status: Disconnected from Database')
            show_message_box('Disconnection Successful', 'Disconnected from the database successfully.', QMessageBox.Information)
            app.stacked_widget.setCurrentIndex(0)
        except Exception as e:
            logging.error(f'Error disconnecting from database: {e}')
            show_message_box('Disconnection Error', f'Error disconnecting from database: {e}', QMessageBox.Critical)
    else:
        show_message_box('Disconnection Error', 'No database connection to disconnect.', QMessageBox.Warning)

def import_excel(app):
    if not app.conn:
        show_message_box('Import Error', 'No database connection established.', QMessageBox.Warning)
        return

    try:
        file_path, _ = QFileDialog.getOpenFileName(app, 'Open Excel File', os.getenv('HOME'), 'Excel Files (*.xlsx *.xls)')
        if not file_path:
            return

        df = pd.read_excel(file_path)
        file_name = os.path.splitext(os.path.basename(file_path))[0]
        app.table_name = file_name

        df.to_sql(app.table_name, con=app.conn, if_exists='replace', index=False)
        show_message_box('Import Successful', f'Excel file imported successfully as table "{app.table_name}".', QMessageBox.Information)
    except Exception as e:
        logging.error(f'Error importing Excel file: {e}')
        show_message_box('Import Error', f'Error importing Excel file: {e}', QMessageBox.Critical)

def lowercase_headers(app):
    try:
        if not app.table_name:
            show_message_box('Error', 'No table name provided.', QMessageBox.Warning)
            return

        df = pd.read_sql_table(app.table_name, app.conn)
        df.columns = [col.lower() for col in df.columns]
        df.to_sql(app.table_name, con=app.conn, if_exists='replace', index=False)
        show_message_box('Lowercase Headers', 'Table headers lowercased successfully.', QMessageBox.Information)
    except Exception as e:
        logging.error(f'Error lowercasing headers: {e}')
        show_message_box('Lowercase Headers Error', f'Error lowercasing headers: {e}', QMessageBox.Critical)

def replace_spaces_in_headers(app):
    try:
        if not app.table_name:
            show_message_box('Error', 'No table name provided.', QMessageBox.Warning)
            return

        df = pd.read_sql_table(app.table_name, app.conn)
        df.columns = [col.replace(' ', '_') for col in df.columns]
        df.to_sql(app.table_name, con=app.conn, if_exists='replace', index=False)
        show_message_box('Replace Spaces in Headers', 'Spaces in headers replaced successfully.', QMessageBox.Information)
    except Exception as e:
        logging.error(f'Error replacing spaces in headers: {e}')
        show_message_box('Replace Spaces in Headers Error', f'Error replacing spaces in headers: {e}', QMessageBox.Critical)

def drop_na_values(app):
    try:
        if not app.table_name:
            show_message_box('Error', 'No table name provided.', QMessageBox.Warning)
            return

        df = pd.read_sql_table(app.table_name, app.conn)
        df = df.dropna()
        df.to_sql(app.table_name, con=app.conn, if_exists='replace', index=False)
        show_message_box('Drop NA Values', 'NA values dropped successfully.', QMessageBox.Information)
    except Exception as e:
        logging.error(f'Error dropping NA values: {e}')
        show_message_box('Drop NA Values Error', f'Error dropping NA values: {e}', QMessageBox.Critical)

def remove_duplicates(app):
    try:
        if not app.table_name:
            show_message_box('Error', 'No table name provided.', QMessageBox.Warning)
            return

        df = pd.read_sql_table(app.table_name, app.conn)
        df = df.drop_duplicates()
        df.to_sql(app.table_name, con=app.conn, if_exists='replace', index=False)
        show_message_box('Remove Duplicates', 'Duplicate rows removed successfully.', QMessageBox.Information)
    except Exception as e:
        logging.error(f'Error removing duplicates: {e}')
        show_message_box('Remove Duplicates Error', f'Error removing duplicates: {e}', QMessageBox.Critical)