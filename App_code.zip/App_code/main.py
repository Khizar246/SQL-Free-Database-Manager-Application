import sys
from PyQt5.QtWidgets import QApplication
from ui_setup import DatabaseApp

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = DatabaseApp()
    window.show()  # Explicitly show the window
    window.raise_()  # Brings the window to the front
    window.activateWindow()  # Activates the window
    sys.exit(app.exec_())
