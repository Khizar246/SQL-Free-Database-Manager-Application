from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QPushButton, QLabel, 
    QSpacerItem, QSizePolicy, QStackedWidget, QMessageBox
)
from PyQt5.QtGui import QFont, QColor
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QGraphicsDropShadowEffect
import pandas as pd
import sqlalchemy as sal
from utils import setup_logging, show_message_box
from database_operations import (
    connect_to_database, disconnect_from_database, import_excel, 
    lowercase_headers, replace_spaces_in_headers, drop_na_values, remove_duplicates
)

setup_logging()

class DatabaseApp(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.conn = None
        self.table_name = None

    def initUI(self):
        self.setWindowTitle('Database Interaction App 📊')
        self.setGeometry(100, 100, 600, 750)
        self.setStyleSheet("background-color: #e0f7fa;")
        
        self.stacked_widget = QStackedWidget(self)
        self.page1 = QWidget()
        self.page2 = QWidget()
        self.create_page1()
        self.create_page2()
        
        self.stacked_widget.addWidget(self.page1)
        self.stacked_widget.addWidget(self.page2)
        self.stacked_widget.setCurrentIndex(0)
        
        layout = QVBoxLayout(self)
        layout.addWidget(self.stacked_widget)
        self.setLayout(layout)
        self.show()

    def create_page1(self):
        self.dialect_edit = self.create_input_field('Enter SQL Dialect (e.g., mysql)')
        self.driver_edit = self.create_input_field('Enter SQL Driver (e.g., pymysql)')
        self.username_edit = self.create_input_field('Enter Username')
        self.password_edit = self.create_input_field('Enter Password', password=True)
        self.host_edit = self.create_input_field('Enter Host Address (e.g., localhost)')
        self.port_edit = self.create_input_field('Enter Port Number (e.g., 3306)')
        self.database_edit = self.create_input_field('Enter Database Name')
        self.table_edit = self.create_input_field('Enter Table Name (optional)')
        
        button_style = """
            QPushButton {
                background-color: #4CAF50;
                border: none;
                color: white;
                padding: 10px 20px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 16px;
                margin: 4px 2px;
                transition-duration: 0.4s;
                cursor: pointer;
                border-radius: 12px;
                font-family: Verdana;
                min-width: 10px;
                min-height: 20px;
            }
            QPushButton:hover {
                background-color: white;
                color: black;
                border: 2px solid #4CAF50;
            }
        """
        
        self.connect_button = QPushButton('Connect to Database')
        self.connect_button.clicked.connect(lambda: connect_to_database(self))
        self.connect_button.setStyleSheet(button_style)
        self.add_shadow_effect(self.connect_button)
        
        app_title_label = QLabel('Database Connection 📊')
        app_title_label.setFont(QFont('Arial', 24, QFont.Bold))
        app_title_label.setStyleSheet("color: #00695c;")
        app_title_label.setAlignment(Qt.AlignCenter)
        
        section_font = QFont('Verdana', 16, QFont.Bold)
        section_style = "color: #004d40;"
        
        db_connection_label = QLabel('Database Connection 🛠️')
        db_connection_label.setFont(section_font)
        db_connection_label.setStyleSheet(section_style)
        
        self.status_label = QLabel('Status: Ready')
        self.status_label.setFont(QFont('Arial', 16, QFont.Bold))
        self.status_label.setStyleSheet("color: #004d40;")
        self.status_label.setAlignment(Qt.AlignCenter)
        
        main_layout = QVBoxLayout()
        main_layout.setAlignment(Qt.AlignTop)
        
        main_layout.addWidget(app_title_label)
        main_layout.addSpacing(20)
        
        form_layout = QVBoxLayout()
        form_layout.setSpacing(10)
        
        form_layout.addWidget(db_connection_label)
        form_layout.addWidget(self.dialect_edit)
        form_layout.addWidget(self.driver_edit)
        form_layout.addWidget(self.username_edit)
        form_layout.addWidget(self.password_edit)
        form_layout.addWidget(self.host_edit)
        form_layout.addWidget(self.port_edit)
        form_layout.addWidget(self.database_edit)
        form_layout.addWidget(self.table_edit)
        form_layout.addWidget(self.connect_button)
        form_layout.addWidget(self.status_label)
        
        center_layout = QHBoxLayout()
        center_layout.addItem(QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
        center_layout.addLayout(form_layout)
        center_layout.addItem(QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
        
        main_layout.addLayout(center_layout)
        
        self.page1.setLayout(main_layout)

    def create_page2(self):
        button_style = """
            QPushButton {
                background-color: #4CAF50;
                border: none;
                color: white;
                padding: 10px 20px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 16px;
                margin: 4px 2px;
                transition-duration: 0.4s;
                cursor: pointer;
                border-radius: 12px;
                font-family: Verdana;
                min-width: 10px;
                min-height: 20px;
            }
            QPushButton:hover {
                background-color: white;
                color: black;
                border: 2px solid #4CAF50;
            }
        """
        
        self.import_button = QPushButton('Import Excel File')
        self.import_button.clicked.connect(lambda: import_excel(self))
        self.import_button.setStyleSheet(button_style)
        self.add_shadow_effect(self.import_button)
        
        self.lowercase_button = QPushButton('Lowercase Headers')
        self.lowercase_button.clicked.connect(lambda: lowercase_headers(self))
        self.lowercase_button.setStyleSheet(button_style)
        self.add_shadow_effect(self.lowercase_button)
        
        self.replace_spaces_button = QPushButton('Replace Spaces in Headers')
        self.replace_spaces_button.clicked.connect(lambda: replace_spaces_in_headers(self))
        self.replace_spaces_button.setStyleSheet(button_style)
        self.add_shadow_effect(self.replace_spaces_button)
        
        self.drop_na_button = QPushButton('Drop NA')
        self.drop_na_button.clicked.connect(lambda: drop_na_values(self))
        self.drop_na_button.setStyleSheet(button_style)
        self.add_shadow_effect(self.drop_na_button)
        
        self.remove_duplicates_button = QPushButton('Remove Duplicates')
        self.remove_duplicates_button.clicked.connect(lambda: remove_duplicates(self))
        self.remove_duplicates_button.setStyleSheet(button_style)
        self.add_shadow_effect(self.remove_duplicates_button)
        
        self.disconnect_button = QPushButton('Disconnect from Database')
        self.disconnect_button.clicked.connect(lambda: disconnect_from_database(self))
        self.disconnect_button.setStyleSheet(button_style)
        self.add_shadow_effect(self.disconnect_button)
        
        section_font = QFont('Verdana', 16, QFont.Bold)
        section_style = "color: #004d40;"
        
        import_data_label = QLabel('Import Data 📥')
        import_data_label.setFont(section_font)
        import_data_label.setStyleSheet(section_style)
        
        data_preparation_label = QLabel('Data Preparation 📝')
        data_preparation_label.setFont(section_font)
        data_preparation_label.setStyleSheet(section_style)
        
        data_cleaning_label = QLabel('Data Cleaning 🧹')
        data_cleaning_label.setFont(section_font)
        data_cleaning_label.setStyleSheet(section_style)
        
        self.status_label = QLabel('Status: Ready')
        self.status_label.setFont(QFont('Arial', 16, QFont.Bold))
        self.status_label.setStyleSheet("color: #004d40;")
        self.status_label.setAlignment(Qt.AlignCenter)
        
        main_layout = QVBoxLayout()
        main_layout.setAlignment(Qt.AlignTop)
        
        form_layout = QVBoxLayout()
        form_layout.setSpacing(10)
        
        form_layout.addWidget(import_data_label)
        form_layout.addWidget(self.import_button)
        
        form_layout.addSpacing(10)
        
        form_layout.addWidget(data_preparation_label)
        form_layout.addWidget(self.lowercase_button)
        form_layout.addWidget(self.replace_spaces_button)
        
        form_layout.addSpacing(10)
        
        form_layout.addWidget(data_cleaning_label)
        form_layout.addWidget(self.drop_na_button)
        form_layout.addWidget(self.remove_duplicates_button)
        
        form_layout.addWidget(self.disconnect_button)
        
        form_layout.addWidget(self.status_label)
        
        center_layout = QHBoxLayout()
        center_layout.addItem(QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
        center_layout.addLayout(form_layout)
        center_layout.addItem(QSpacerItem(0, 0, QSizePolicy.Expanding, QSizePolicy.Minimum))
        
        main_layout.addLayout(center_layout)
        
        self.page2.setLayout(main_layout)

    def create_input_field(self, placeholder_text, password=False):
        input_field = QLineEdit()
        input_field.setPlaceholderText(placeholder_text)
        input_field.setFont(QFont('Arial', 14))
        
        if password:
            input_field.setEchoMode(QLineEdit.Password)
        
        input_field.setStyleSheet("""
            QLineEdit {
                border: 1px solid #4CAF50;
                border-radius: 10px;
                padding: 10px;
                font-family: Arial;
                font-size: 14px;
            }
            QLineEdit:focus {
                border: 2px solid #4CAF50;
            }
        """)
        
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(10)
        shadow.setColor(QColor(0, 0, 0, 160))
        shadow.setOffset(2, 2)
        input_field.setGraphicsEffect(shadow)
        
        return input_field

    def add_shadow_effect(self, button):
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(15)
        shadow.setColor(QColor(0, 0, 0, 160))
        shadow.setOffset(3, 3)
        button.setGraphicsEffect(shadow)