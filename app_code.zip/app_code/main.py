import sys  # Import the sys module to access system-specific parameters and functions
from PyQt5.QtWidgets import QApplication  # Import QApplication from PyQt5 to create the application
from ui import DatabaseApp  # Import the DatabaseApp class from the ui module

# Main entry point of the application
if __name__ == '__main__':
    print("Starting the application...")  # Print a message indicating that the application is starting
    app = QApplication(sys.argv)  # Create an instance of QApplication, passing in the command line arguments
    window = DatabaseApp()  # Create an instance of the DatabaseApp class
    window.show()  # Explicitly show the main window
    window.raise_()  # Bring the main window to the front
    window.activateWindow()  # Activate the main window
    sys.exit(app.exec_())  # Enter the main event loop and wait until exit