from PyQt5.QtWidgets import QLineEdit, QGraphicsDropShadowEffect, QMessageBox  # Import necessary PyQt5 widgets
from PyQt5.QtGui import QFont, QColor  # Import QFont and QColor for setting fonts and colors

def create_input_field(placeholder_text, password=False):
    """
    Create a QLineEdit with shadow effect and border.

    Parameters:
    placeholder_text (str): The placeholder text for the input field.
    password (bool): If True, the input field will be used for password input.

    Returns:
    QLineEdit: The created input field with the specified properties.
    """
    input_field = QLineEdit()  # Create a QLineEdit widget
    input_field.setPlaceholderText(placeholder_text)  # Set the placeholder text
    input_field.setFont(QFont('Arial', 14))  # Set the font of the text

    if password:
        input_field.setEchoMode(QLineEdit.Password)  # If password is True, set the echo mode to Password

    # Set the style sheet for the input field
    input_field.setStyleSheet("""
        QLineEdit {
            border: 1px solid #4CAF50;
            border-radius: 10px;
            padding: 10px;
            font-family: Arial;
            font-size: 14px;
        }
        QLineEdit:focus {
            border: 2px solid #4CAF50;
        }
    """)

    # Create and set a drop shadow effect for the input field
    shadow = QGraphicsDropShadowEffect()
    shadow.setBlurRadius(10)
    shadow.setColor(QColor(0, 0, 0, 160))
    shadow.setOffset(2, 2)
    input_field.setGraphicsEffect(shadow)

    return input_field  # Return the created input field

def add_shadow_effect(button):
    """
    Add a shadow effect to a given button.

    Parameters:
    button (QPushButton): The button to which the shadow effect will be added.
    """
    # Create and set a drop shadow effect for the button
    shadow = QGraphicsDropShadowEffect()
    shadow.setBlurRadius(15)
    shadow.setColor(QColor(0, 0, 0, 160))
    shadow.setOffset(3, 3)
    button.setGraphicsEffect(shadow)

def show_message_box(title, message, icon):
    """
    Show a message box with the given title, message, and icon.

    Parameters:
    title (str): The title of the message box.
    message (str): The message to be displayed in the message box.
    icon (QMessageBox.Icon): The icon to be displayed in the message box.
    """
    msg_box = QMessageBox()  # Create a QMessageBox widget
    msg_box.setWindowTitle(title)  # Set the title of the message box
    msg_box.setText(message)  # Set the message text of the message box
    msg_box.setIcon(icon)  # Set the icon of the message box
    msg_box.exec_()  # Execute the message box (display it)